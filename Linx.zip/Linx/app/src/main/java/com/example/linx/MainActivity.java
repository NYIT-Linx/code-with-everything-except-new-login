package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {


    ImageButton chatImageButton;
    ImageButton orgImageButton;
    ImageButton locatorImageButton;
    ImageButton busImageButton;
    ImageButton cafeImageButton;
    ImageButton eventImageButton;
    ImageButton advisorImageButton;
    ImageButton profileImageButton;
    ImageButton scheduleImageButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        chatImageButton = (ImageButton) findViewById(R.id.chats);

        chatImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intentLoadNewActivity = new Intent(MainActivity.this, classroomchatsmain.class);
                //startActivity(intentLoadNewActivity);
            }
        });
        orgImageButton = (ImageButton) findViewById(R.id.org);

        orgImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, organizationmenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        locatorImageButton = (ImageButton) findViewById(R.id.locator);

        locatorImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, roomlocator.class);
                startActivity(intentLoadNewActivity);
            }
        });
        busImageButton = (ImageButton) findViewById(R.id.bus);

        busImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, bus.class);
                startActivity(intentLoadNewActivity);
            }
        });
        cafeImageButton = (ImageButton) findViewById(R.id.cafe);

        cafeImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, cafemenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        eventImageButton = (ImageButton) findViewById(R.id.event);

        eventImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, eventsmenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        advisorImageButton = (ImageButton) findViewById(R.id.advisor);

        advisorImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, advisormenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        profileImageButton = (ImageButton) findViewById(R.id.profile);

        profileImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, profilemenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        scheduleImageButton = (ImageButton) findViewById(R.id.schedule);

        scheduleImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, schedule.class);
                startActivity(intentLoadNewActivity);
            }
        });

    }
}