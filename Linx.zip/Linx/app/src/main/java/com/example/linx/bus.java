package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.os.Bundle;

public class bus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus);
        Spinner mySpinner = (Spinner) findViewById(R.id.spinnerX);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<>(bus.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==1){
                    startActivity(new Intent(bus.this,
                            n_y_i_t_o_w_campus.class));

                }
                if(i==2){
                    startActivity(new Intent(bus.this,
                            hicksville_l_i_r_r_shuttle.class));
                }
                if(i==3) {
                    startActivity(new Intent(bus.this,
                            manhasset_l_i_r_r_shuttle.class));
                }
                if(i==4) {
                    startActivity(new Intent(bus.this,
                            internal_campus_shuttle.class));
                }
                if(i==5) {
                    startActivity(new Intent(bus.this,
                            s_u_n_y_off_campus_shuttle.class));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
    });
}
}
