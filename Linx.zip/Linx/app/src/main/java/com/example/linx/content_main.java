package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class content_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
    }
}