package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class s_u_n_y_off_campus_shuttle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_u_n_y_off_campus_shuttle);
    }
}