package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class manhasset_l_i_r_r_shuttle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manhasset_l_i_r_r_shuttle);
    }
}