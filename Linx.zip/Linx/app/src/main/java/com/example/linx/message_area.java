package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class message_area extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_area);
    }
}