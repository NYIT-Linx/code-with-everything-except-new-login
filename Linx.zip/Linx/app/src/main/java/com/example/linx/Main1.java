package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class Main1 extends AppCompatActivity {

    private EditText UserName;
    private EditText Password;
    private Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UserName = (EditText)findViewById(R.id.UserName);
        Password = (EditText)findViewById(R.id.Password);
        Login = (Button)findViewById(R.id.Submit);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(UserName.getText().toString(), Password.getText().toString());
            }
        });


    }

    private void validate(String userName, String userPassword){
        if((userName == ("wrauf")) && (userPassword == ("Admin"))) {
            Intent intent = new Intent(Main1.this, Main2.class);
            startActivity(intent);
        }else{
            Intent intent2 = new Intent(Main1.this, Main2.class);
            startActivity(intent2);
        }
    }
}
