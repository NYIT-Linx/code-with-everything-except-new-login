package com.example.linx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class their_messsage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_their_messsage);
    }
}